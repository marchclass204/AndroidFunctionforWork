package com.march_lab;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class main extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    public void onBtnClicked001(View v){
        Toast.makeText(this, "clicked", Toast.LENGTH_LONG).show();
    }
}
